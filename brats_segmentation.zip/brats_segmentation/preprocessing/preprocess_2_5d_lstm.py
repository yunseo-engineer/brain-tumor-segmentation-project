"""
preprocessing/preprocess_2_5d_lstm.py
=====================================
2.5D U-Net + LSTM용 전처리.

입력: 3D volume (240, 240, 155, 4)
처리:
  - Z-score 정규화 + Brain crop + padding
  - 연속 slice sequence 생성 (T=8 sliding window, stride=4)
  - 각 sequence: (T, H, W, 4) image + (T, H, W, 3) mask
  - crop/padding metadata 저장
출력: 환자별 sequence .npy 파일들 + metadata JSON
"""

import os
import sys
import json
import numpy as np
from tqdm import tqdm

sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from utils.dataset import (
    find_patient_dirs, load_nifti_volume, convert_labels_to_regions,
    zscore_normalize, crop_and_pad, get_patient_split, save_split_info,
)


# ============================================================
# 설정
# ============================================================

DATA_ROOT = "/kaggle/input/brats20-dataset-training-validation/BraTS2020_TrainingData/MICCAI_BraTS2020_TrainingData"
OUTPUT_ROOT = "/kaggle/working/preprocessed_2_5d_lstm"
TARGET_H, TARGET_W, TARGET_D = 192, 192, 144
BRAIN_VOXEL_THRESHOLD = 500
SEQUENCE_LEN = 8   # T: 한 시퀀스의 연속 slice 수
STRIDE = 4          # 슬라이딩 윈도우 stride


def preprocess_patient(patient_dir: str, output_dir: str, split_name: str):
    """환자 1명을 LSTM sequence format으로 전처리."""
    patient_id = os.path.basename(patient_dir)

    # 1) 로드 → 변환 → 정규화 → crop/pad
    volume, seg, affine = load_nifti_volume(patient_dir)
    mask = convert_labels_to_regions(seg)
    volume = zscore_normalize(volume)
    vol_padded, mask_padded, crop_meta = crop_and_pad(
        volume, mask, TARGET_H, TARGET_W, TARGET_D
    )

    num_slices = vol_padded.shape[2]
    save_dir = os.path.join(output_dir, split_name, patient_id)
    os.makedirs(save_dir, exist_ok=True)

    # 유효한 slice 인덱스 (brain voxel 기준)
    valid_z = []
    for z in range(num_slices):
        brain_voxels = (vol_padded[:, :, z, :].sum(axis=-1) > 0).sum()
        if brain_voxels >= BRAIN_VOXEL_THRESHOLD:
            valid_z.append(z)

    if len(valid_z) < SEQUENCE_LEN:
        # 유효 slice가 T보다 적으면 패딩
        while len(valid_z) < SEQUENCE_LEN:
            valid_z.append(valid_z[-1])

    # Sliding window로 sequence 생성
    seq_count = 0
    seq_info = []

    for start in range(0, len(valid_z) - SEQUENCE_LEN + 1, STRIDE):
        z_indices = valid_z[start:start + SEQUENCE_LEN]

        # (T, H, W, 4) image sequence
        img_seq = np.stack([vol_padded[:, :, z, :] for z in z_indices], axis=0)
        # (T, H, W, 3) mask sequence
        mask_seq = np.stack([mask_padded[:, :, z, :] for z in z_indices], axis=0)

        seq_name = f"{patient_id}_seq{seq_count:03d}"
        np.save(os.path.join(save_dir, f"{seq_name}_seq_image.npy"), img_seq)
        np.save(os.path.join(save_dir, f"{seq_name}_seq_mask.npy"), mask_seq)

        has_tumor = mask_seq.sum() > 0
        has_et = mask_seq[..., 2].sum() > 0
        seq_info.append({
            "seq_name": seq_name,
            "z_indices": z_indices,
            "has_tumor": bool(has_tumor),
            "has_et": bool(has_et),
        })
        seq_count += 1

    # Metadata 저장
    patient_meta = {
        "patient_id": patient_id,
        "split": split_name,
        "crop_metadata": crop_meta,
        "affine": affine.tolist(),
        "sequence_len": SEQUENCE_LEN,
        "stride": STRIDE,
        "total_sequences": seq_count,
        "valid_slices": len(valid_z),
        "et_present": any(s["has_et"] for s in seq_info),
        "seq_info": seq_info,
    }

    meta_path = os.path.join(save_dir, f"{patient_id}_metadata.json")
    with open(meta_path, "w") as f:
        json.dump(patient_meta, f, indent=2)

    return patient_meta


def main():
    print("=" * 60)
    print("  BraTS 2020 — 2.5D LSTM Preprocessing")
    print("=" * 60)

    patient_dirs = find_patient_dirs(DATA_ROOT)
    print(f"Found {len(patient_dirs)} patients")

    train_dirs, val_dirs, test_dirs = get_patient_split(patient_dirs)
    print(f"Split: Train={len(train_dirs)}, Val={len(val_dirs)}, Test={len(test_dirs)}")

    os.makedirs(OUTPUT_ROOT, exist_ok=True)
    save_split_info(train_dirs, val_dirs, test_dirs,
                    os.path.join(OUTPUT_ROOT, "split_info.json"))

    all_meta = []
    for split_name, dirs in [("train", train_dirs), ("val", val_dirs), ("test", test_dirs)]:
        print(f"\nProcessing {split_name} set ({len(dirs)} patients)...")
        for patient_dir in tqdm(dirs, desc=split_name):
            try:
                meta = preprocess_patient(patient_dir, OUTPUT_ROOT, split_name)
                all_meta.append(meta)
            except Exception as e:
                print(f"Error processing {os.path.basename(patient_dir)}: {e}")

    summary = {
        "total_patients": len(all_meta),
        "total_sequences": sum(m["total_sequences"] for m in all_meta),
        "et_absent_patients": sum(1 for m in all_meta if not m["et_present"]),
        "sequence_len": SEQUENCE_LEN,
        "stride": STRIDE,
        "target_shape": [TARGET_H, TARGET_W, TARGET_D],
    }
    with open(os.path.join(OUTPUT_ROOT, "preprocessing_summary.json"), "w") as f:
        json.dump(summary, f, indent=2)

    print(f"\nDone! Total sequences: {summary['total_sequences']}")


if __name__ == "__main__":
    main()
