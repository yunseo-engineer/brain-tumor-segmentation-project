"""
preprocessing/preprocess_2d.py
==============================
2D U-Net baseline용 전처리.

입력: 3D volume (240, 240, 155, 4)
처리:
  - Z-score 정규화 (brain mask 내부 기준)
  - Brain crop → padding to fixed size
  - Z축 방향으로 axial slice 추출
  - 빈 slice 제거 (brain voxel threshold)
  - crop/padding metadata 저장
출력: 환자별 2D slice .npy 파일들 + metadata JSON
"""

import os
import sys
import json
import numpy as np
from tqdm import tqdm

# 프로젝트 루트를 path에 추가
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from utils.dataset import (
    find_patient_dirs, load_nifti_volume, convert_labels_to_regions,
    zscore_normalize, crop_and_pad, get_patient_split, save_split_info,
)


# ============================================================
# 설정
# ============================================================

# Kaggle 데이터 경로 (환경에 맞게 수정)
DATA_ROOT = "/kaggle/input/brats20-dataset-training-validation/BraTS2020_TrainingData/MICCAI_BraTS2020_TrainingData"

# 출력 경로
OUTPUT_ROOT = "/kaggle/working/preprocessed_2d"

# Brain crop target 크기
TARGET_H, TARGET_W, TARGET_D = 192, 192, 144

# 빈 slice 제거 기준: brain voxel (non-zero) 수가 이 값 미만이면 제거
BRAIN_VOXEL_THRESHOLD = 500


def preprocess_patient(patient_dir: str, output_dir: str, split_name: str):
    """
    환자 1명을 전처리하여 2D slice .npy로 저장.

    Returns
    -------
    patient_meta : dict — 해당 환자의 metadata
    """
    patient_id = os.path.basename(patient_dir)

    # 1) NIfTI 로드
    volume, seg, affine = load_nifti_volume(patient_dir)

    # 2) Label 변환 → WT/TC/ET 3채널
    mask = convert_labels_to_regions(seg)

    # 3) Z-score 정규화
    volume = zscore_normalize(volume)

    # 4) Brain crop + padding (metadata 저장)
    vol_padded, mask_padded, crop_meta = crop_and_pad(
        volume, mask, TARGET_H, TARGET_W, TARGET_D
    )

    # 5) Axial slice 추출 + 빈 slice 제거
    save_dir = os.path.join(output_dir, split_name, patient_id)
    os.makedirs(save_dir, exist_ok=True)

    slice_count = 0
    slice_info = []

    for z in range(vol_padded.shape[2]):
        img_slice = vol_padded[:, :, z, :]   # (H, W, 4)
        mask_slice = mask_padded[:, :, z, :]  # (H, W, 3)

        # 빈 slice 제거
        brain_voxels = (img_slice.sum(axis=-1) > 0).sum()
        if brain_voxels < BRAIN_VOXEL_THRESHOLD:
            continue

        # 저장
        slice_name = f"{patient_id}_z{z:03d}"
        np.save(os.path.join(save_dir, f"{slice_name}_image.npy"), img_slice)
        np.save(os.path.join(save_dir, f"{slice_name}_mask.npy"), mask_slice)

        has_tumor = mask_slice.sum() > 0
        slice_info.append({
            "slice_name": slice_name,
            "z_index": z,
            "brain_voxels": int(brain_voxels),
            "has_tumor": bool(has_tumor),
            "wt_pixels": int(mask_slice[..., 0].sum()),
            "tc_pixels": int(mask_slice[..., 1].sum()),
            "et_pixels": int(mask_slice[..., 2].sum()),
        })
        slice_count += 1

    # 6) Patient metadata 저장
    patient_meta = {
        "patient_id": patient_id,
        "split": split_name,
        "crop_metadata": crop_meta,
        "affine": affine.tolist(),
        "total_slices": slice_count,
        "tumor_slices": sum(1 for s in slice_info if s["has_tumor"]),
        "et_present": any(s["et_pixels"] > 0 for s in slice_info),
        "slice_info": slice_info,
    }

    meta_path = os.path.join(save_dir, f"{patient_id}_metadata.json")
    with open(meta_path, "w") as f:
        json.dump(patient_meta, f, indent=2)

    return patient_meta


def main():
    print("=" * 60)
    print("  BraTS 2020 — 2D Preprocessing")
    print("=" * 60)

    # 환자 디렉토리 탐색
    patient_dirs = find_patient_dirs(DATA_ROOT)
    print(f"Found {len(patient_dirs)} patients")

    # 환자 단위 split
    train_dirs, val_dirs, test_dirs = get_patient_split(patient_dirs)
    print(f"Split: Train={len(train_dirs)}, Val={len(val_dirs)}, Test={len(test_dirs)}")

    # Split 정보 저장
    os.makedirs(OUTPUT_ROOT, exist_ok=True)
    save_split_info(train_dirs, val_dirs, test_dirs,
                    os.path.join(OUTPUT_ROOT, "split_info.json"))

    # 전처리 실행
    all_meta = []
    for split_name, dirs in [("train", train_dirs), ("val", val_dirs), ("test", test_dirs)]:
        print(f"\nProcessing {split_name} set ({len(dirs)} patients)...")
        for patient_dir in tqdm(dirs, desc=split_name):
            try:
                meta = preprocess_patient(patient_dir, OUTPUT_ROOT, split_name)
                all_meta.append(meta)
            except Exception as e:
                print(f"Error processing {os.path.basename(patient_dir)}: {e}")

    # 전체 메타데이터 저장
    summary = {
        "total_patients": len(all_meta),
        "total_slices": sum(m["total_slices"] for m in all_meta),
        "et_absent_patients": sum(1 for m in all_meta if not m["et_present"]),
        "target_shape": [TARGET_H, TARGET_W, TARGET_D],
        "brain_voxel_threshold": BRAIN_VOXEL_THRESHOLD,
    }
    with open(os.path.join(OUTPUT_ROOT, "preprocessing_summary.json"), "w") as f:
        json.dump(summary, f, indent=2)

    print(f"\nDone! Total slices: {summary['total_slices']}")
    print(f"ET-absent patients: {summary['et_absent_patients']}")
    print(f"Output: {OUTPUT_ROOT}")


if __name__ == "__main__":
    main()
