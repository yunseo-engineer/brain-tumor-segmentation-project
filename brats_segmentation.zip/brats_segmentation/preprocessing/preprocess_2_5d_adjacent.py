"""
preprocessing/preprocess_2_5d_adjacent.py
=========================================
2.5D U-Net++ / Transformer용 전처리.

입력: 3D volume (240, 240, 155, 4)
처리:
  - Z-score 정규화 + Brain crop + padding
  - 각 axial slice i에 대해 [i-2, i-1, i, i+1, i+2] 5장 stack
  - 경계 처리: 첫/마지막 slice는 mirror padding
  - 입력 shape per sample: (H, W, 20) — 5 slices × 4 modality
  - 정답 mask: 중앙 slice i 기준 (H, W, 3)
  - crop/padding metadata 저장
출력: 환자별 2.5D adjacent sample .npy + metadata JSON
"""

import os
import sys
import json
import numpy as np
from tqdm import tqdm

sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from utils.dataset import (
    find_patient_dirs, load_nifti_volume, convert_labels_to_regions,
    zscore_normalize, crop_and_pad, get_patient_split, save_split_info,
)


# ============================================================
# 설정
# ============================================================

DATA_ROOT = "/kaggle/input/brats20-dataset-training-validation/BraTS2020_TrainingData/MICCAI_BraTS2020_TrainingData"
OUTPUT_ROOT = "/kaggle/working/preprocessed_2_5d_adjacent"
TARGET_H, TARGET_W, TARGET_D = 192, 192, 144
BRAIN_VOXEL_THRESHOLD = 500
ADJACENT_RADIUS = 2  # ±2 slices → 5장 총


def preprocess_patient(patient_dir: str, output_dir: str, split_name: str):
    """환자 1명을 2.5D adjacent format으로 전처리."""
    patient_id = os.path.basename(patient_dir)

    # 1) 로드 → 변환 → 정규화 → crop/pad
    volume, seg, affine = load_nifti_volume(patient_dir)
    mask = convert_labels_to_regions(seg)
    volume = zscore_normalize(volume)
    vol_padded, mask_padded, crop_meta = crop_and_pad(
        volume, mask, TARGET_H, TARGET_W, TARGET_D
    )

    num_slices = vol_padded.shape[2]  # D dimension
    save_dir = os.path.join(output_dir, split_name, patient_id)
    os.makedirs(save_dir, exist_ok=True)

    slice_count = 0
    slice_info = []

    for z in range(num_slices):
        # 중앙 slice의 brain voxel 확인
        center_slice = vol_padded[:, :, z, :]
        brain_voxels = (center_slice.sum(axis=-1) > 0).sum()
        if brain_voxels < BRAIN_VOXEL_THRESHOLD:
            continue

        # ±2 인접 slice stack (mirror padding for boundary)
        adjacent_slices = []
        for offset in range(-ADJACENT_RADIUS, ADJACENT_RADIUS + 1):
            z_adj = z + offset
            # Mirror padding for boundary
            if z_adj < 0:
                z_adj = -z_adj
            elif z_adj >= num_slices:
                z_adj = 2 * (num_slices - 1) - z_adj

            z_adj = np.clip(z_adj, 0, num_slices - 1)
            adjacent_slices.append(vol_padded[:, :, z_adj, :])  # (H, W, 4)

        # Stack: 5 slices × 4 modality = 20 channels
        image_25d = np.concatenate(adjacent_slices, axis=-1)  # (H, W, 20)
        mask_center = mask_padded[:, :, z, :]  # (H, W, 3) — 중앙 slice mask

        # 저장
        slice_name = f"{patient_id}_z{z:03d}"
        np.save(os.path.join(save_dir, f"{slice_name}_image.npy"), image_25d)
        np.save(os.path.join(save_dir, f"{slice_name}_mask.npy"), mask_center)

        has_tumor = mask_center.sum() > 0
        slice_info.append({
            "slice_name": slice_name,
            "z_index": z,
            "has_tumor": bool(has_tumor),
            "et_pixels": int(mask_center[..., 2].sum()),
        })
        slice_count += 1

    # Metadata 저장
    patient_meta = {
        "patient_id": patient_id,
        "split": split_name,
        "crop_metadata": crop_meta,
        "affine": affine.tolist(),
        "adjacent_radius": ADJACENT_RADIUS,
        "total_slices": slice_count,
        "tumor_slices": sum(1 for s in slice_info if s["has_tumor"]),
        "et_present": any(s["et_pixels"] > 0 for s in slice_info),
        "slice_info": slice_info,
    }

    meta_path = os.path.join(save_dir, f"{patient_id}_metadata.json")
    with open(meta_path, "w") as f:
        json.dump(patient_meta, f, indent=2)

    return patient_meta


def main():
    print("=" * 60)
    print("  BraTS 2020 — 2.5D Adjacent Preprocessing")
    print("=" * 60)

    patient_dirs = find_patient_dirs(DATA_ROOT)
    print(f"Found {len(patient_dirs)} patients")

    train_dirs, val_dirs, test_dirs = get_patient_split(patient_dirs)
    print(f"Split: Train={len(train_dirs)}, Val={len(val_dirs)}, Test={len(test_dirs)}")

    os.makedirs(OUTPUT_ROOT, exist_ok=True)
    save_split_info(train_dirs, val_dirs, test_dirs,
                    os.path.join(OUTPUT_ROOT, "split_info.json"))

    all_meta = []
    for split_name, dirs in [("train", train_dirs), ("val", val_dirs), ("test", test_dirs)]:
        print(f"\nProcessing {split_name} set ({len(dirs)} patients)...")
        for patient_dir in tqdm(dirs, desc=split_name):
            try:
                meta = preprocess_patient(patient_dir, OUTPUT_ROOT, split_name)
                all_meta.append(meta)
            except Exception as e:
                print(f"Error processing {os.path.basename(patient_dir)}: {e}")

    summary = {
        "total_patients": len(all_meta),
        "total_slices": sum(m["total_slices"] for m in all_meta),
        "et_absent_patients": sum(1 for m in all_meta if not m["et_present"]),
        "adjacent_radius": ADJACENT_RADIUS,
        "input_channels": (2 * ADJACENT_RADIUS + 1) * 4,
        "target_shape": [TARGET_H, TARGET_W, TARGET_D],
    }
    with open(os.path.join(OUTPUT_ROOT, "preprocessing_summary.json"), "w") as f:
        json.dump(summary, f, indent=2)

    print(f"\nDone! Total slices: {summary['total_slices']}")
    print(f"Input channels: {summary['input_channels']}")


if __name__ == "__main__":
    main()
