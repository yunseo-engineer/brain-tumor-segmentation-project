"""
preprocessing/preprocess_2_5d_multiview.py
==========================================
2.5D Multi-view ensemble용 전처리.

핵심 원칙:
  - Coronal / Sagittal은 resize 대신 **padding 우선** (aspect ratio 보존)
  - crop/padding metadata 저장 (복원용)
  - 3개 view를 각각 독립적으로 저장

입력: 3D volume (240, 240, 155, 4)
처리:
  - Z-score 정규화 + Brain crop + padding
  - Axial:    vol[:, :, i, :]  → (H, W, 4)
  - Coronal:  vol[:, j, :, :]  → (H, D, 4) → padding to (H, H, 4)
  - Sagittal: vol[k, :, :, :]  → (W, D, 4) → padding to (W, W, 4)
  - resize 대신 zero-padding으로 정사각형 만들기 (정보 왜곡 방지)
출력: view별 .npy (axial/, coronal/, sagittal/) + metadata JSON
"""

import os
import sys
import json
import numpy as np
from tqdm import tqdm

sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from utils.dataset import (
    find_patient_dirs, load_nifti_volume, convert_labels_to_regions,
    zscore_normalize, crop_and_pad, get_patient_split, save_split_info,
)


# ============================================================
# 설정
# ============================================================

DATA_ROOT = "/kaggle/input/brats20-dataset-training-validation/BraTS2020_TrainingData/MICCAI_BraTS2020_TrainingData"
OUTPUT_ROOT = "/kaggle/working/preprocessed_2_5d_multiview"
TARGET_H, TARGET_W, TARGET_D = 192, 192, 144
BRAIN_VOXEL_THRESHOLD = 300  # multi-view에서는 낮은 threshold (coronal/sagittal은 brain 면적이 작을 수 있음)


def pad_to_square(image: np.ndarray, mask: np.ndarray):
    """
    비정사각형 slice를 zero-padding으로 정사각형으로 만들기.
    resize 대신 padding을 사용하여 aspect ratio와 pixel 값 보존.

    Parameters
    ----------
    image : (H1, H2, C) — H1 ≠ H2 가능
    mask  : (H1, H2, 3)

    Returns
    -------
    img_padded  : (max_dim, max_dim, C)
    mask_padded : (max_dim, max_dim, 3)
    pad_meta    : dict — padding 정보 (복원용)
    """
    h1, h2 = image.shape[:2]
    max_dim = max(h1, h2)

    img_padded = np.zeros((max_dim, max_dim, image.shape[-1]), dtype=image.dtype)
    mask_padded = np.zeros((max_dim, max_dim, 3), dtype=mask.dtype)

    # 중앙 정렬
    offset_h = (max_dim - h1) // 2
    offset_w = (max_dim - h2) // 2

    img_padded[offset_h:offset_h + h1, offset_w:offset_w + h2, :] = image
    mask_padded[offset_h:offset_h + h1, offset_w:offset_w + h2, :] = mask

    pad_meta = {
        "original_shape": [h1, h2],
        "padded_shape": [max_dim, max_dim],
        "offset_h": offset_h,
        "offset_w": offset_w,
    }

    return img_padded, mask_padded, pad_meta


def extract_view_slices(vol: np.ndarray, mask: np.ndarray, view: str):
    """
    지정된 view에서 2D slice를 추출.

    Parameters
    ----------
    vol  : (H, W, D, 4) — crop+pad된 volume
    mask : (H, W, D, 3)
    view : "axial", "coronal", "sagittal"

    Returns
    -------
    slices : list of (image, mask, slice_index, pad_meta)
    """
    slices = []

    if view == "axial":
        # vol[:, :, z, :]  → (H, W, 4), 이미 정사각형
        for z in range(vol.shape[2]):
            img = vol[:, :, z, :]
            msk = mask[:, :, z, :]
            brain = (img.sum(axis=-1) > 0).sum()
            if brain >= BRAIN_VOXEL_THRESHOLD:
                slices.append((img, msk, z, {"view": "axial", "original_shape": list(img.shape[:2])}))

    elif view == "coronal":
        # vol[:, y, :, :]  → (H, D, 4), H ≠ D → padding
        for y in range(vol.shape[1]):
            img = vol[:, y, :, :]    # (H, D, 4)
            msk = mask[:, y, :, :]   # (H, D, 3)
            brain = (img.sum(axis=-1) > 0).sum()
            if brain >= BRAIN_VOXEL_THRESHOLD:
                img_sq, msk_sq, pad_meta = pad_to_square(img, msk)
                pad_meta["view"] = "coronal"
                pad_meta["slice_axis_index"] = y
                slices.append((img_sq, msk_sq, y, pad_meta))

    elif view == "sagittal":
        # vol[x, :, :, :]  → (W, D, 4), W ≠ D → padding
        for x in range(vol.shape[0]):
            img = vol[x, :, :, :]    # (W, D, 4)
            msk = mask[x, :, :, :]   # (W, D, 3)
            brain = (img.sum(axis=-1) > 0).sum()
            if brain >= BRAIN_VOXEL_THRESHOLD:
                img_sq, msk_sq, pad_meta = pad_to_square(img, msk)
                pad_meta["view"] = "sagittal"
                pad_meta["slice_axis_index"] = x
                slices.append((img_sq, msk_sq, x, pad_meta))

    return slices


def preprocess_patient(patient_dir: str, output_dir: str, split_name: str):
    """환자 1명을 3 view로 전처리."""
    patient_id = os.path.basename(patient_dir)

    # 로드 → 변환 → 정규화 → crop/pad
    volume, seg, affine = load_nifti_volume(patient_dir)
    mask = convert_labels_to_regions(seg)
    volume = zscore_normalize(volume)
    vol_padded, mask_padded, crop_meta = crop_and_pad(
        volume, mask, TARGET_H, TARGET_W, TARGET_D
    )

    view_stats = {}

    for view in ["axial", "coronal", "sagittal"]:
        view_dir = os.path.join(output_dir, split_name, view, patient_id)
        os.makedirs(view_dir, exist_ok=True)

        slices = extract_view_slices(vol_padded, mask_padded, view)

        slice_info = []
        for img, msk, idx, pad_meta in slices:
            slice_name = f"{patient_id}_{view}_{idx:03d}"
            np.save(os.path.join(view_dir, f"{slice_name}_image.npy"), img)
            np.save(os.path.join(view_dir, f"{slice_name}_mask.npy"), msk)

            slice_info.append({
                "slice_name": slice_name,
                "slice_index": idx,
                "has_tumor": bool(msk.sum() > 0),
                "et_pixels": int(msk[..., 2].sum()),
                "pad_meta": pad_meta,
            })

        view_stats[view] = {
            "num_slices": len(slices),
            "tumor_slices": sum(1 for s in slice_info if s["has_tumor"]),
            "slice_info": slice_info,
        }

    # Patient metadata (3 view 통합)
    patient_meta = {
        "patient_id": patient_id,
        "split": split_name,
        "crop_metadata": crop_meta,
        "affine": affine.tolist(),
        "views": view_stats,
        "et_present": any(
            s["et_pixels"] > 0
            for v in view_stats.values()
            for s in v["slice_info"]
        ),
    }

    meta_path = os.path.join(output_dir, split_name, f"{patient_id}_multiview_metadata.json")
    with open(meta_path, "w") as f:
        json.dump(patient_meta, f, indent=2)

    return patient_meta


def main():
    print("=" * 60)
    print("  BraTS 2020 — 2.5D Multi-view Preprocessing")
    print("  (Padding-first, no resize)")
    print("=" * 60)

    patient_dirs = find_patient_dirs(DATA_ROOT)
    print(f"Found {len(patient_dirs)} patients")

    train_dirs, val_dirs, test_dirs = get_patient_split(patient_dirs)
    print(f"Split: Train={len(train_dirs)}, Val={len(val_dirs)}, Test={len(test_dirs)}")

    os.makedirs(OUTPUT_ROOT, exist_ok=True)
    save_split_info(train_dirs, val_dirs, test_dirs,
                    os.path.join(OUTPUT_ROOT, "split_info.json"))

    all_meta = []
    for split_name, dirs in [("train", train_dirs), ("val", val_dirs), ("test", test_dirs)]:
        print(f"\nProcessing {split_name} set ({len(dirs)} patients)...")
        for patient_dir in tqdm(dirs, desc=split_name):
            try:
                meta = preprocess_patient(patient_dir, OUTPUT_ROOT, split_name)
                all_meta.append(meta)
            except Exception as e:
                print(f"Error processing {os.path.basename(patient_dir)}: {e}")

    summary = {
        "total_patients": len(all_meta),
        "et_absent_patients": sum(1 for m in all_meta if not m["et_present"]),
        "padding_strategy": "zero-padding to square (no resize)",
        "target_volume_shape": [TARGET_H, TARGET_W, TARGET_D],
        "views": ["axial", "coronal", "sagittal"],
    }
    with open(os.path.join(OUTPUT_ROOT, "preprocessing_summary.json"), "w") as f:
        json.dump(summary, f, indent=2)

    print(f"\nDone!")
    print(f"Padding strategy: zero-padding (aspect ratio preserved)")


if __name__ == "__main__":
    main()
