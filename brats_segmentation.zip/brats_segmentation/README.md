# 🧠 BraTS 2020 뇌종양 Segmentation: Jupyter Notebook 버전

**py 파일을 모두 Jupyter Notebook (.ipynb)로 변환했습니다!**

이제 **Kaggle Notebook이나 Google Colab에서 cell 단위로 실행하면서 결과를 바로바로 확인**할 수 있습니다.

---

## 📂 파일 구조

```
brats_segmentation/
├── 01_eda.ipynb                    # 📊 EDA (탐색적 데이터 분석) — 데이터 파악
│
├── preprocessing/                  # 📥 데이터 전처리 (여전히 .py)
│   ├── preprocess_2d.py            # 2D 슬라이스 전처리
│   ├── preprocess_2_5d_adjacent.py # 2.5D 인접 슬라이스 전처리
│   ├── preprocess_2_5d_lstm.py     # LSTM용 sequence 전처리
│   └── preprocess_2_5d_multiview.py # Multi-view 전처리
│
├── models/                         # 🧠 5가지 모델 (모두 .ipynb)
│   ├── 02_2d_unet.ipynb            # 2D U-Net (baseline)
│   ├── 03_2_5d_unetpp.ipynb        # 2.5D U-Net++ (nested skip)
│   ├── 04_2_5d_unet_lstm.ipynb     # 2.5D U-Net + LSTM (시퀀스 맥락)
│   ├── 05_2_5d_transformer.ipynb   # 2.5D Transformer (TransUNet)
│   └── 06_2_5d_multiview_ensemble.ipynb # 2.5D Multi-view Ensemble
│
├── utils/                          # 🔧 공통 유틸리티
│   ├── dataset.py                  # Dataset 클래스, NIfTI 로드, 정규화
│   ├── metrics.py                  # Dice, HD95 (3D volume 단위)
│   ├── losses.py                   # DiceBCE, Tversky Loss
│   ├── visualization.py            # 시각화 함수
│   └── __init__.py
│
└── results/                        # 📊 결과 저장 폴더
    ├── model_metrics.csv           # 모델 비교 결과
    └── predictions/                # 환자별 예측 결과
```

---

## 🚀 빠른 시작

### **1단계: 데이터 준비**

Kaggle Notebook에서 진행하는 것을 **강력히 추천**합니다:
- ✅ BraTS 2020 데이터셋이 이미 `/kaggle/input/` 에 있음
- ✅ P100 GPU 16GB 무료 사용 가능

**또는 Google Colab:**
- 수동으로 데이터를 마운트해야 함 (번거로움)

### **2단계: 전처리 실행**

**Terminal (Kaggle Notebook에서 "Code" cell 실행):**

```bash
# 2D 전처리
python preprocessing/preprocess_2d.py

# 또는 다른 전처리
python preprocessing/preprocess_2_5d_adjacent.py
python preprocessing/preprocess_2_5d_lstm.py
python preprocessing/preprocess_2_5d_multiview.py
```

전처리 후 `/kaggle/working/preprocessed_*/` 디렉토리가 생성됩니다.

### **3단계: 모델 학습 + 평가 (Jupyter에서!)**

Kaggle Notebook 또는 Google Colab에서 각 notebook을 열고 **cell 단위로 실행**:

```
📊 01_eda.ipynb
    ↓ (데이터 특성 파악)
🧠 models/02_2d_unet.ipynb         (baseline)
🧠 models/03_2_5d_unetpp.ipynb     (fine-grained)
🧠 models/04_2_5d_unet_lstm.ipynb  (temporal context)
🧠 models/05_2_5d_transformer.ipynb (global attention)
🧠 models/06_2_5d_multiview_ensemble.ipynb (3-view ensemble)
```

---

## 📖 각 Notebook의 구조

### **01_eda.ipynb**

| Cell | 내용 | 결과 |
|------|------|------|
| 1 | 환자 수, 데이터 shape 확인 | 기본 통계 |
| 2-3 | 첫 환자의 modality 확인 | 이미지 shape, label 확인 |
| 4-5 | Intensity 분포 히스토그램 | 정규화 전략 결정 |
| 6-7 | 종양 분포 분석 | 클래스 불균형 확인 |
| 8-10 | 종양 위치 heatmap (3-view) | 어디에 종양이 자주 나타나는지 |
| 11-12 | 종양 크기 분포 | 어려운 케이스 식별 |
| 13+ | 시각화 샘플 | 대표 환자 이미지 + mask overlay |

**중간중간 그래프가 나타나므로 결과를 바로바로 확인할 수 있습니다!** 📊

---

### **02_2d_unet.ipynb ~ 06_2_5d_multiview_ensemble.ipynb**

각 모델 notebook의 typical flow:

| Cell 섹션 | 내용 |
|---------|------|
| 제목 & 설명 | 모델 개요, 입출력 정보 |
| Import & 설정 | 라이브러리, 하이퍼파라미터 |
| Dataset | Data loading, batch 구성 |
| 아키텍처 정의 | 모델 클래스 |
| 학습 함수 | train_one_epoch, validate |
| 3D Volume 평가 함수 | 핵심: slice → volume 재조합 → Dice/HD95 |
| 메인 학습 루프 | Epoch 반복, 중간 결과 출력 |
| Best 모델 로드 & Test 평가 | 최종 결과 저장 |

**각 cell을 순서대로 실행하면:**
1. ✅ 첫 몇 epoch의 학습 로그 실시간 표시
2. ✅ Validation loss 그래프 표시 (각 epoch마다 업데이트)
3. ✅ Best model 저장 메시지
4. ✅ Test set 3D volume 평가 결과 **즉시 출력**
5. ✅ CSV 결과 파일 저장 완료 메시지

---

## 💡 추천 실행 순서

### **Option A: 전체 파이프라인 (권장)**

```
1️⃣ 01_eda.ipynb
    ↓ (데이터 이해)
2️⃣ Terminal에서 전처리 실행
    ↓ 각 전처리 .py 스크립트 실행
3️⃣ 02_2d_unet.ipynb
    ↓ Cell 단위 실행 → 결과 확인
4️⃣ 03_2_5d_unetpp.ipynb
    ↓ Cell 단위 실행
5️⃣ (시간이 충분하면) 04, 05, 06도 동일
```

### **Option B: 빠른 테스트**

```
1️⃣ 01_eda.ipynb (10분)
    ↓
2️⃣ preprocess_2d.py (30분)
    ↓
3️⃣ 02_2d_unet.ipynb (1시간) ← baseline 성능 빨리 보기
```

---

## 🎯 Jupyter에서 Cell 실행하기

### **Kaggle Notebook 기준:**

1. **Cell 실행**: `Shift + Enter` 또는 ▶️ 버튼
2. **Cell 출력 실시간 확인** ✅
3. **그래프 바로 표시** (plt.show() 자동 실행)
4. **에러 발생 시**: Cell 중단 후 수정 가능
5. **결과 재사용**: 이전 cell의 변수 접근 가능

### **예시: 모델 학습 중간 결과 확인**

```python
# Cell 1: 데이터 로드
for epoch in range(1, 51):
    train_loss = train_one_epoch(...)
    val_loss = validate(...)
    
    if epoch % 5 == 0:
        print(f"✅ Epoch {epoch}: train={train_loss:.4f}, val={val_loss:.4f}")
        # ← Cell 실행 중에도 실시간으로 출력 표시!
```

---

## ⚠️ 주의사항

### **전처리는 여전히 .py (Terminal에서)**

```bash
# Notebook이 아니라 Terminal에서 실행
cd brats_segmentation/
python preprocessing/preprocess_2d.py
```

이유:
- 전처리는 시간이 오래 걸림 (각 5~30분)
- 한 번 실행하면 끝 (재실행 필요 없음)
- 출력 결과도 많지 않음 (메모리 절약)

### **모델은 .ipynb (Notebook에서)**

```
각 모델을 별개의 notebook에서 독립적으로 실행 가능
Cell 단위 실행 → 중간 결과 확인 가능
```

---

## 📊 결과 확인

### **1. 학습 중 실시간 결과**

Notebook에서 각 epoch마다:
```
Epoch 1/50
  Train Loss: 0.5234 | Val Loss: 0.4821
  ✅ Best model saved

Epoch 2/50
  Train Loss: 0.4812 | Val Loss: 0.4567
  ...
```

### **2. Test 평가 결과**

```
============================================================
  3D Volume-Level Evaluation on Test Set
============================================================

WT (Whole Tumor):
  Mean Dice: 0.892 ± 0.045
  Mean HD95: 5.23 ± 2.11

TC (Tumor Core):
  Mean Dice: 0.845 ± 0.068
  ...

ET (Enhancing Tumor):
  Mean Dice: 0.761 ± 0.095
  ET-absent patients: 12
```

### **3. CSV 결과 저장**

- `results/model_metrics.csv` ← 모든 모델의 최종 성능 비교
- `results/*_patient_metrics.csv` ← 환자별 상세 결과

---

## 🔧 커스터마이징 (필요시)

Notebook에서 **직접 수정 가능**:

```python
# Cell 수정 예시
BATCH_SIZE = 32  # 기본값 16 → 32로 변경
NUM_EPOCHS = 100  # 기본값 50 → 100으로 변경
LR = 1e-3  # learning rate 조정

# Cell 다시 실행하면 새 설정으로 학습 시작
```

---

## 📞 실행 중 문제 해결

| 문제 | 해결 |
|------|------|
| `ModuleNotFoundError: No module named 'nibabel'` | `pip install nibabel` |
| `CUDA out of memory` | `BATCH_SIZE` 줄이기 (16 → 8) |
| Cell이 멈춘 것처럼 보임 | 학습 중입니다. 기다리세요 (Epoch당 5-10분) |
| GPU 없음 | Kaggle/Colab 무료 GPU 사용 (권장) |

---

## 🎓 학습 순서 (권장)

1. **01_eda.ipynb** 부터 시작 → 데이터 이해
2. **전처리 1가지만** 먼저 (2d)
3. **02_2d_unet.ipynb** 실행 → baseline 이해
4. **다른 전처리 & 모델들** 순차 실행

---

## 📝 요약

| 항목 | 설명 |
|------|------|
| **형식** | Jupyter Notebook (.ipynb) |
| **실행 환경** | Kaggle Notebook ✅ / Google Colab / Jupyter |
| **장점** | Cell 단위 실행, 결과 즉시 확인, 디버깅 용이 |
| **전처리** | Terminal에서 python 실행 (한 번만) |
| **모델 학습** | Notebook에서 Cell 실행 (중간 결과 확인) |

**지금 바로 Kaggle Notebook에서 `01_eda.ipynb`를 열고 첫 cell을 실행해보세요!** 🚀

