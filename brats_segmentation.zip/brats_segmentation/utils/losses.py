"""
utils/losses.py
===============
Segmentation 학습용 Loss 함수들.

- DiceLoss: region별 Dice loss
- DiceBCELoss: Dice + Binary Cross Entropy (기본)
- TverskyLoss: FP/FN에 다른 가중치 부여 (recall 중시)
"""

import torch
import torch.nn as nn


class DiceLoss(nn.Module):
    """
    Soft Dice Loss (region별 평균).

    pred, gt: (B, C, H, W) where C=3 (WT, TC, ET)
    """

    def __init__(self, smooth: float = 1.0):
        super().__init__()
        self.smooth = smooth

    def forward(self, pred: torch.Tensor, gt: torch.Tensor):
        pred = torch.sigmoid(pred)
        B, C = pred.shape[:2]

        pred_flat = pred.view(B, C, -1)
        gt_flat = gt.view(B, C, -1)

        intersection = (pred_flat * gt_flat).sum(dim=2)
        union = pred_flat.sum(dim=2) + gt_flat.sum(dim=2)

        dice = (2.0 * intersection + self.smooth) / (union + self.smooth)
        return 1.0 - dice.mean()


class DiceBCELoss(nn.Module):
    """
    Dice Loss + Binary Cross Entropy Loss (가중 합).

    기본 비율: dice_weight=1.0, bce_weight=1.0
    """

    def __init__(self, dice_weight: float = 1.0, bce_weight: float = 1.0,
                 smooth: float = 1.0):
        super().__init__()
        self.dice_weight = dice_weight
        self.bce_weight = bce_weight
        self.dice_loss = DiceLoss(smooth=smooth)
        self.bce_loss = nn.BCEWithLogitsLoss()

    def forward(self, pred: torch.Tensor, gt: torch.Tensor):
        dice = self.dice_loss(pred, gt)
        bce = self.bce_loss(pred, gt)
        return self.dice_weight * dice + self.bce_weight * bce


class TverskyLoss(nn.Module):
    """
    Tversky Loss — FP와 FN에 다른 가중치를 부여.

    alpha > beta: FP에 더 큰 패널티 → Precision 중시
    alpha < beta: FN에 더 큰 패널티 → Recall 중시 (의료 영상 추천)

    기본값: alpha=0.3, beta=0.7 (Recall 중시)
    """

    def __init__(self, alpha: float = 0.3, beta: float = 0.7, smooth: float = 1.0):
        super().__init__()
        self.alpha = alpha
        self.beta = beta
        self.smooth = smooth

    def forward(self, pred: torch.Tensor, gt: torch.Tensor):
        pred = torch.sigmoid(pred)
        B, C = pred.shape[:2]

        pred_flat = pred.view(B, C, -1)
        gt_flat = gt.view(B, C, -1)

        tp = (pred_flat * gt_flat).sum(dim=2)
        fp = (pred_flat * (1.0 - gt_flat)).sum(dim=2)
        fn = ((1.0 - pred_flat) * gt_flat).sum(dim=2)

        tversky = (tp + self.smooth) / (tp + self.alpha * fp + self.beta * fn + self.smooth)
        return 1.0 - tversky.mean()
