"""
utils/dataset.py
================
공통 Dataset 클래스 및 전처리 헬퍼 함수.

핵심 원칙:
- 환자(volume) 단위 split (seed=42, 7:1:2)
- Z-score 정규화 (brain mask 내부 기준)
- Brain crop → padding to fixed size (crop/padding metadata 저장)
- Label 변환: {0,1,2,4} → WT/TC/ET binary 3채널
- ET 없는 환자 예외 처리
"""

import os
import glob
import json
import numpy as np
import nibabel as nib
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset
import torch


# ============================================================
# 1. 데이터 경로 탐색
# ============================================================

def find_patient_dirs(data_root: str):
    """BraTS20_Training_XXX 폴더들을 정렬하여 리턴."""
    dirs = sorted(glob.glob(os.path.join(data_root, "BraTS20_Training_*")))
    dirs = [d for d in dirs if os.path.isdir(d)]
    return dirs


def load_nifti_volume(patient_dir: str):
    """
    환자 1명의 4 modality + seg를 로드.

    Returns
    -------
    volume : np.ndarray, shape (240, 240, 155, 4)  — float32
        채널 순서: [flair, t1, t1ce, t2]
    seg    : np.ndarray, shape (240, 240, 155)      — int16
        원본 label (0, 1, 2, 4)
    affine : np.ndarray, shape (4, 4)
        NIfTI affine matrix (원본 좌표 복원용)
    """
    patient_id = os.path.basename(patient_dir)
    modalities = ["flair", "t1", "t1ce", "t2"]

    channels = []
    for mod in modalities:
        path = os.path.join(patient_dir, f"{patient_id}_{mod}.nii.gz")
        nii = nib.load(path)
        channels.append(nii.get_fdata().astype(np.float32))

    volume = np.stack(channels, axis=-1)  # (240, 240, 155, 4)

    seg_path = os.path.join(patient_dir, f"{patient_id}_seg.nii.gz")
    seg_nii = nib.load(seg_path)
    seg = seg_nii.get_fdata().astype(np.int16)
    affine = seg_nii.affine

    return volume, seg, affine


# ============================================================
# 2. Label 변환
# ============================================================

def convert_labels_to_regions(seg: np.ndarray):
    """
    원본 label {0,1,2,4} → 3채널 binary region mask.

    Returns
    -------
    mask : np.ndarray, shape (*seg.shape, 3)  — uint8
        채널: [WT, TC, ET]
        WT = {1, 2, 4}
        TC = {1, 4}
        ET = {4}
    """
    wt = ((seg == 1) | (seg == 2) | (seg == 4)).astype(np.uint8)
    tc = ((seg == 1) | (seg == 4)).astype(np.uint8)
    et = (seg == 4).astype(np.uint8)
    mask = np.stack([wt, tc, et], axis=-1)
    return mask


# ============================================================
# 3. Z-score 정규화 (brain mask 내부 기준)
# ============================================================

def zscore_normalize(volume: np.ndarray):
    """
    환자별, modality별, brain mask 내부 기준 Z-score 정규화.

    Parameters
    ----------
    volume : (H, W, D, C) float32

    Returns
    -------
    normalized : (H, W, D, C) float32
        brain 외부는 0으로 유지
    """
    normalized = np.zeros_like(volume)
    for c in range(volume.shape[-1]):
        ch = volume[..., c]
        brain_mask = ch > 0
        if brain_mask.sum() == 0:
            continue
        brain_voxels = ch[brain_mask]
        mean = brain_voxels.mean()
        std = brain_voxels.std() + 1e-8
        normalized[..., c][brain_mask] = (ch[brain_mask] - mean) / std
    return normalized


# ============================================================
# 4. Brain crop + padding (metadata 저장)
# ============================================================

def compute_brain_bbox(volume: np.ndarray):
    """
    0이 아닌 voxel의 3D bounding box 계산.

    Parameters
    ----------
    volume : (H, W, D, C)

    Returns
    -------
    bbox : dict with keys 'h_min','h_max','w_min','w_max','d_min','d_max'
    """
    brain_mask = volume.sum(axis=-1) > 0  # (H, W, D)
    h_idx, w_idx, d_idx = np.where(brain_mask)

    if len(h_idx) == 0:
        # 전체가 비어있는 경우 (있을 수 없지만 안전장치)
        return {
            "h_min": 0, "h_max": volume.shape[0],
            "w_min": 0, "w_max": volume.shape[1],
            "d_min": 0, "d_max": volume.shape[2],
        }

    return {
        "h_min": int(h_idx.min()), "h_max": int(h_idx.max()) + 1,
        "w_min": int(w_idx.min()), "w_max": int(w_idx.max()) + 1,
        "d_min": int(d_idx.min()), "d_max": int(d_idx.max()) + 1,
    }


def crop_and_pad(volume: np.ndarray, mask: np.ndarray,
                 target_h: int = 192, target_w: int = 192, target_d: int = 144):
    """
    Brain bounding box로 crop 후, target 크기로 zero-padding.

    Returns
    -------
    vol_padded  : (target_h, target_w, target_d, C) float32
    mask_padded : (target_h, target_w, target_d, 3) uint8
    metadata    : dict — crop bbox + padding offsets (복원에 필요)
    """
    bbox = compute_brain_bbox(volume)

    # Crop
    vol_crop = volume[bbox["h_min"]:bbox["h_max"],
                      bbox["w_min"]:bbox["w_max"],
                      bbox["d_min"]:bbox["d_max"], :]
    mask_crop = mask[bbox["h_min"]:bbox["h_max"],
                     bbox["w_min"]:bbox["w_max"],
                     bbox["d_min"]:bbox["d_max"], :]

    ch, cw, cd = vol_crop.shape[:3]

    # 크기 검증: crop이 target보다 크면 중앙 crop
    if ch > target_h:
        start = (ch - target_h) // 2
        vol_crop = vol_crop[start:start + target_h]
        mask_crop = mask_crop[start:start + target_h]
        ch = target_h
    if cw > target_w:
        start = (cw - target_w) // 2
        vol_crop = vol_crop[:, start:start + target_w]
        mask_crop = mask_crop[:, start:start + target_w]
        cw = target_w
    if cd > target_d:
        start = (cd - target_d) // 2
        vol_crop = vol_crop[:, :, start:start + target_d]
        mask_crop = mask_crop[:, :, start:start + target_d]
        cd = target_d

    # Padding (중앙 정렬)
    pad_h = (target_h - ch) // 2
    pad_w = (target_w - cw) // 2
    pad_d = (target_d - cd) // 2

    vol_padded = np.zeros((target_h, target_w, target_d, volume.shape[-1]),
                          dtype=np.float32)
    mask_padded = np.zeros((target_h, target_w, target_d, 3), dtype=np.uint8)

    vol_padded[pad_h:pad_h + ch, pad_w:pad_w + cw, pad_d:pad_d + cd, :] = vol_crop
    mask_padded[pad_h:pad_h + ch, pad_w:pad_w + cw, pad_d:pad_d + cd, :] = mask_crop

    metadata = {
        "original_shape": list(volume.shape[:3]),
        "crop_bbox": bbox,
        "cropped_shape": [ch, cw, cd],
        "target_shape": [target_h, target_w, target_d],
        "padding_offset": {"h": pad_h, "w": pad_w, "d": pad_d},
    }

    return vol_padded, mask_padded, metadata


def restore_to_original(pred_padded: np.ndarray, metadata: dict):
    """
    패딩/크롭된 예측 결과를 원래 (240,240,155) 공간으로 복원.

    Parameters
    ----------
    pred_padded : (target_h, target_w, target_d, 3) — 모델 예측
    metadata    : crop_and_pad에서 저장한 metadata

    Returns
    -------
    pred_orig : (H_orig, W_orig, D_orig, 3) — 원본 공간 예측
    """
    orig_shape = metadata["original_shape"]  # [H, W, D]
    bbox = metadata["crop_bbox"]
    pad = metadata["padding_offset"]
    cs = metadata["cropped_shape"]

    # 패딩 제거 → crop된 크기
    pred_crop = pred_padded[pad["h"]:pad["h"] + cs[0],
                            pad["w"]:pad["w"] + cs[1],
                            pad["d"]:pad["d"] + cs[2], :]

    # 원본 크기 볼륨에 넣기
    pred_orig = np.zeros((orig_shape[0], orig_shape[1], orig_shape[2], 3),
                         dtype=pred_crop.dtype)
    pred_orig[bbox["h_min"]:bbox["h_min"] + cs[0],
              bbox["w_min"]:bbox["w_min"] + cs[1],
              bbox["d_min"]:bbox["d_min"] + cs[2], :] = pred_crop

    return pred_orig


# ============================================================
# 5. 환자 단위 Split (고정 seed)
# ============================================================

def get_patient_split(patient_dirs: list, seed: int = 42):
    """
    환자 단위 7:1:2 split.

    Returns
    -------
    train_dirs, val_dirs, test_dirs : list[str]
    """
    # 먼저 train+val (80%) vs test (20%)
    trainval, test = train_test_split(
        patient_dirs, test_size=0.20, random_state=seed
    )
    # train (70% of total=87.5% of trainval) vs val (10% of total=12.5% of trainval)
    train, val = train_test_split(
        trainval, test_size=0.125, random_state=seed
    )
    return train, val, test


def save_split_info(train_dirs, val_dirs, test_dirs, output_path: str):
    """Split 정보를 JSON으로 저장."""
    info = {
        "train": [os.path.basename(d) for d in train_dirs],
        "val": [os.path.basename(d) for d in val_dirs],
        "test": [os.path.basename(d) for d in test_dirs],
        "num_train": len(train_dirs),
        "num_val": len(val_dirs),
        "num_test": len(test_dirs),
    }
    with open(output_path, "w") as f:
        json.dump(info, f, indent=2)
    return info


# ============================================================
# 6. PyTorch Dataset Classes
# ============================================================

class BraTS2DDataset(Dataset):
    """2D axial slice dataset."""

    def __init__(self, slice_dir: str, transform=None, tumor_only: bool = False):
        """
        Parameters
        ----------
        slice_dir : 전처리된 .npy 파일들이 있는 디렉토리
        transform : albumentations 또는 custom transform
        tumor_only : True면 종양 있는 slice만 사용
        """
        self.transform = transform
        self.samples = sorted(glob.glob(os.path.join(slice_dir, "*_image.npy")))
        if tumor_only:
            self.samples = [s for s in self.samples
                            if np.load(s.replace("_image.npy", "_mask.npy")).sum() > 0]

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path = self.samples[idx]
        mask_path = img_path.replace("_image.npy", "_mask.npy")

        image = np.load(img_path).astype(np.float32)   # (H, W, C)
        mask = np.load(mask_path).astype(np.float32)    # (H, W, 3)

        if self.transform:
            augmented = self.transform(image=image, mask=mask)
            image, mask = augmented["image"], augmented["mask"]

        # (H, W, C) → (C, H, W)  for PyTorch
        image = torch.from_numpy(image.transpose(2, 0, 1))
        mask = torch.from_numpy(mask.transpose(2, 0, 1))

        return image, mask


class BraTS25DAdjacentDataset(Dataset):
    """2.5D adjacent slice dataset (5 slices × 4 modality = 20ch)."""

    def __init__(self, sample_dir: str, transform=None):
        self.transform = transform
        self.samples = sorted(glob.glob(os.path.join(sample_dir, "*_image.npy")))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path = self.samples[idx]
        mask_path = img_path.replace("_image.npy", "_mask.npy")

        image = np.load(img_path).astype(np.float32)   # (H, W, 20)
        mask = np.load(mask_path).astype(np.float32)    # (H, W, 3)

        if self.transform:
            augmented = self.transform(image=image, mask=mask)
            image, mask = augmented["image"], augmented["mask"]

        image = torch.from_numpy(image.transpose(2, 0, 1))
        mask = torch.from_numpy(mask.transpose(2, 0, 1))

        return image, mask


class BraTS25DLSTMDataset(Dataset):
    """2.5D LSTM sequence dataset (T, H, W, 4)."""

    def __init__(self, sample_dir: str):
        self.samples = sorted(glob.glob(os.path.join(sample_dir, "*_seq_image.npy")))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path = self.samples[idx]
        mask_path = img_path.replace("_seq_image.npy", "_seq_mask.npy")

        image = np.load(img_path).astype(np.float32)   # (T, H, W, 4)
        mask = np.load(mask_path).astype(np.float32)    # (T, H, W, 3)

        # (T, H, W, C) → (T, C, H, W)
        image = torch.from_numpy(image.transpose(0, 3, 1, 2))
        mask = torch.from_numpy(mask.transpose(0, 3, 1, 2))

        return image, mask


class BraTSMultiViewDataset(Dataset):
    """Multi-view dataset for one specific view."""

    def __init__(self, slice_dir: str, transform=None):
        self.transform = transform
        self.samples = sorted(glob.glob(os.path.join(slice_dir, "*_image.npy")))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path = self.samples[idx]
        mask_path = img_path.replace("_image.npy", "_mask.npy")

        image = np.load(img_path).astype(np.float32)
        mask = np.load(mask_path).astype(np.float32)

        if self.transform:
            augmented = self.transform(image=image, mask=mask)
            image, mask = augmented["image"], augmented["mask"]

        image = torch.from_numpy(image.transpose(2, 0, 1))
        mask = torch.from_numpy(mask.transpose(2, 0, 1))

        return image, mask
