"""
utils/visualization.py
======================
Slice 시각화, overlay, 3 view 시각화 유틸리티.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


# BraTS region 색상 (WT=노랑, TC=주황, ET=빨강)
REGION_COLORS = {
    "wt": [1.0, 1.0, 0.0],    # yellow
    "tc": [1.0, 0.6, 0.0],    # orange
    "et": [1.0, 0.0, 0.0],    # red
}


def create_overlay(image_slice: np.ndarray, mask_slice: np.ndarray,
                   alpha: float = 0.4):
    """
    MRI slice에 segmentation mask를 overlay.

    Parameters
    ----------
    image_slice : (H, W) 또는 (H, W, C) — 단일 modality slice
    mask_slice  : (H, W, 3) — [WT, TC, ET] binary
    alpha       : overlay 투명도

    Returns
    -------
    overlay : (H, W, 3) — RGB overlay 이미지
    """
    if image_slice.ndim == 3:
        image_slice = image_slice[..., 0]  # 첫 채널 사용

    # Normalize to [0, 1]
    img = image_slice.astype(np.float32)
    if img.max() > 0:
        img = (img - img.min()) / (img.max() - img.min() + 1e-8)

    # Grayscale → RGB
    base = np.stack([img, img, img], axis=-1)

    # Overlay (ET > TC > WT 순으로 덮어쓰기)
    overlay = base.copy()
    for i, region in enumerate(["wt", "tc", "et"]):
        region_mask = mask_slice[..., i].astype(bool)
        if region_mask.sum() > 0:
            color = np.array(REGION_COLORS[region])
            overlay[region_mask] = (1 - alpha) * base[region_mask] + alpha * color

    return np.clip(overlay, 0, 1)


def plot_patient_sample(volume: np.ndarray, mask: np.ndarray,
                        slice_idx: int = None, modality_names=None,
                        save_path: str = None):
    """
    환자 1명의 4 modality + mask overlay를 axial view로 시각화.

    Parameters
    ----------
    volume : (H, W, D, 4) — 정규화된 volume
    mask   : (H, W, D, 3) — region mask [WT, TC, ET]
    slice_idx : 표시할 axial slice 인덱스 (None이면 종양이 큰 slice 자동 선택)
    """
    if modality_names is None:
        modality_names = ["FLAIR", "T1", "T1ce", "T2"]

    if slice_idx is None:
        # 종양이 가장 큰 slice 자동 선택
        tumor_area = mask[..., 0].sum(axis=(0, 1))  # WT channel, sum per slice
        slice_idx = int(np.argmax(tumor_area))

    fig, axes = plt.subplots(1, 5, figsize=(20, 4))

    for i, (ax, name) in enumerate(zip(axes[:4], modality_names)):
        ax.imshow(volume[:, :, slice_idx, i], cmap="gray")
        ax.set_title(name, fontsize=12)
        ax.axis("off")

    # Overlay
    overlay = create_overlay(volume[:, :, slice_idx, 0], mask[:, :, slice_idx, :])
    axes[4].imshow(overlay)
    axes[4].set_title("Overlay", fontsize=12)
    axes[4].axis("off")

    # Legend
    patches = [
        mpatches.Patch(color=REGION_COLORS["wt"], label="WT"),
        mpatches.Patch(color=REGION_COLORS["tc"], label="TC"),
        mpatches.Patch(color=REGION_COLORS["et"], label="ET"),
    ]
    fig.legend(handles=patches, loc="lower center", ncol=3, fontsize=10)

    plt.suptitle(f"Axial Slice {slice_idx}", fontsize=14)
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


def plot_three_views(volume: np.ndarray, mask: np.ndarray,
                     indices: dict = None, save_path: str = None):
    """
    Axial / Coronal / Sagittal 3 view에서 overlay 시각화.

    Parameters
    ----------
    volume : (H, W, D, C) — 모델 입력 volume
    mask   : (H, W, D, 3) — region mask
    indices : {"axial": int, "coronal": int, "sagittal": int}
              None이면 각 축에서 종양이 가장 큰 slice 자동 선택
    """
    if indices is None:
        indices = {}
        wt = mask[..., 0]
        indices["axial"] = int(np.argmax(wt.sum(axis=(0, 1))))
        indices["coronal"] = int(np.argmax(wt.sum(axis=(0, 2))))
        indices["sagittal"] = int(np.argmax(wt.sum(axis=(1, 2))))

    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    view_names = ["Axial", "Coronal", "Sagittal"]

    for ax, (view, name) in zip(axes, zip(
            ["axial", "coronal", "sagittal"], view_names)):
        idx = indices[view]
        if view == "axial":
            img = volume[:, :, idx, 0]
            msk = mask[:, :, idx, :]
        elif view == "coronal":
            img = volume[:, idx, :, 0]
            msk = mask[:, idx, :, :]
        else:
            img = volume[idx, :, :, 0]
            msk = mask[idx, :, :, :]

        overlay = create_overlay(img, msk)
        ax.imshow(overlay)
        ax.set_title(f"{name} (slice {idx})", fontsize=12)
        ax.axis("off")

    patches = [
        mpatches.Patch(color=REGION_COLORS["wt"], label="WT"),
        mpatches.Patch(color=REGION_COLORS["tc"], label="TC"),
        mpatches.Patch(color=REGION_COLORS["et"], label="ET"),
    ]
    fig.legend(handles=patches, loc="lower center", ncol=3, fontsize=10)
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


def plot_prediction_comparison(image_slice: np.ndarray,
                               gt_mask: np.ndarray,
                               pred_mask: np.ndarray,
                               title: str = "",
                               save_path: str = None):
    """
    GT vs Prediction overlay 비교 시각화.

    Parameters
    ----------
    image_slice : (H, W) — 단일 modality
    gt_mask     : (H, W, 3)
    pred_mask   : (H, W, 3)
    """
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))

    # 원본
    axes[0].imshow(image_slice, cmap="gray")
    axes[0].set_title("Original MRI")
    axes[0].axis("off")

    # GT overlay
    gt_overlay = create_overlay(image_slice, gt_mask)
    axes[1].imshow(gt_overlay)
    axes[1].set_title("Ground Truth")
    axes[1].axis("off")

    # Prediction overlay
    pred_overlay = create_overlay(image_slice, pred_mask)
    axes[2].imshow(pred_overlay)
    axes[2].set_title("Prediction")
    axes[2].axis("off")

    patches = [
        mpatches.Patch(color=REGION_COLORS["wt"], label="WT"),
        mpatches.Patch(color=REGION_COLORS["tc"], label="TC"),
        mpatches.Patch(color=REGION_COLORS["et"], label="ET"),
    ]
    fig.legend(handles=patches, loc="lower center", ncol=3, fontsize=10)

    if title:
        plt.suptitle(title, fontsize=14)
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()
