"""
utils/metrics.py
================
3D Volume 단위 Dice / HD95 계산.

핵심 원칙:
- 평가는 반드시 3D volume 단위 (slice 단위 평가 X)
- ET 없는 환자에 대한 예외 처리 (GT가 비어있을 때)
- HD95는 예측과 GT 모두 비어있으면 0, 한쪽만 비어있으면 max penalty
"""

import numpy as np
from scipy.ndimage import distance_transform_edt


# ============================================================
# Dice Coefficient (3D volume 단위)
# ============================================================

def dice_coefficient(pred: np.ndarray, gt: np.ndarray, eps: float = 1e-7):
    """
    단일 region에 대한 Dice 계산 (3D volume 단위).

    Parameters
    ----------
    pred : (H, W, D) binary (0 or 1)
    gt   : (H, W, D) binary (0 or 1)

    Returns
    -------
    dice : float (0~1), None if both are empty
    """
    pred = pred.astype(bool)
    gt = gt.astype(bool)

    # 둘 다 비어있는 경우 (예: ET가 없는 GT + 모델도 ET를 예측하지 않음)
    if gt.sum() == 0 and pred.sum() == 0:
        return 1.0  # perfect: 없는 것을 없다고 예측

    # GT는 있는데 예측이 없거나, GT는 없는데 예측한 경우
    if gt.sum() == 0 or pred.sum() == 0:
        return 0.0

    intersection = (pred & gt).sum()
    return (2.0 * intersection + eps) / (pred.sum() + gt.sum() + eps)


# ============================================================
# Hausdorff Distance 95 (3D volume 단위)
# ============================================================

def hausdorff_distance_95(pred: np.ndarray, gt: np.ndarray,
                          voxel_spacing: tuple = (1.0, 1.0, 1.0),
                          max_dist: float = 373.13):
    """
    3D 95th percentile Hausdorff Distance.

    Parameters
    ----------
    pred : (H, W, D) binary
    gt   : (H, W, D) binary
    voxel_spacing : voxel 크기 (mm), BraTS는 보통 (1, 1, 1)
    max_dist : 최대 거리 (한쪽만 비어있을 때 페널티)
               BraTS 240×240×155에서 대각선 ≈ 373.13

    Returns
    -------
    hd95 : float (mm), None-safe
    """
    pred = pred.astype(bool)
    gt = gt.astype(bool)

    # 둘 다 비어있으면 HD95 = 0 (완벽한 경우)
    if pred.sum() == 0 and gt.sum() == 0:
        return 0.0

    # 한쪽만 비어있으면 최대 페널티
    if pred.sum() == 0 or gt.sum() == 0:
        return max_dist

    # Surface distance 계산
    pred_border = _get_surface(pred)
    gt_border = _get_surface(gt)

    # Distance transform (GT surface까지의 거리 map)
    dt_gt = distance_transform_edt(~gt_border, sampling=voxel_spacing)
    dt_pred = distance_transform_edt(~pred_border, sampling=voxel_spacing)

    # pred surface → gt surface까지 거리
    dist_pred_to_gt = dt_gt[pred_border]
    # gt surface → pred surface까지 거리
    dist_gt_to_pred = dt_pred[gt_border]

    all_distances = np.concatenate([dist_pred_to_gt, dist_gt_to_pred])

    return float(np.percentile(all_distances, 95))


def _get_surface(binary_mask: np.ndarray):
    """3D binary mask의 surface (경계) voxel 추출."""
    from scipy.ndimage import binary_erosion
    eroded = binary_erosion(binary_mask, iterations=1)
    surface = binary_mask & ~eroded
    return surface


# ============================================================
# Volume 단위 평가 함수 (3 region 통합)
# ============================================================

def evaluate_volume(pred_volume: np.ndarray, gt_volume: np.ndarray,
                    patient_id: str = "",
                    voxel_spacing: tuple = (1.0, 1.0, 1.0)):
    """
    환자 1명의 3D volume에 대해 WT/TC/ET Dice + HD95 계산.

    Parameters
    ----------
    pred_volume : (H, W, D, 3) — 채널 [WT, TC, ET] binary
    gt_volume   : (H, W, D, 3) — 채널 [WT, TC, ET] binary
    patient_id  : 로그용 환자 ID
    voxel_spacing : voxel 크기 (mm)

    Returns
    -------
    metrics : dict
        {
            "patient_id": str,
            "dice_wt": float, "dice_tc": float, "dice_et": float,
            "hd95_wt": float, "hd95_tc": float, "hd95_et": float,
            "et_present_in_gt": bool,  # ET가 GT에 존재하는지
        }
    """
    regions = ["wt", "tc", "et"]
    metrics = {"patient_id": patient_id}

    for i, region in enumerate(regions):
        pred_r = pred_volume[..., i]
        gt_r = gt_volume[..., i]

        # ET 없는 환자 플래그
        gt_has_region = gt_r.sum() > 0

        # Dice
        d = dice_coefficient(pred_r, gt_r)
        metrics[f"dice_{region}"] = d

        # HD95
        h = hausdorff_distance_95(pred_r, gt_r, voxel_spacing=voxel_spacing)
        metrics[f"hd95_{region}"] = h

        # ET 존재 여부 (ET에 한해 기록)
        if region == "et":
            metrics["et_present_in_gt"] = gt_has_region

    return metrics


def aggregate_metrics(all_patient_metrics: list, exclude_et_absent: bool = True):
    """
    전체 환자 metric을 집계.

    Parameters
    ----------
    all_patient_metrics : list of dict (evaluate_volume의 결과)
    exclude_et_absent : True면 ET가 GT에 없는 환자는 ET Dice/HD95 평균에서 제외

    Returns
    -------
    summary : dict
        {
            "mean_dice_wt": float, "std_dice_wt": float,
            "mean_dice_tc": float, "std_dice_tc": float,
            "mean_dice_et": float, "std_dice_et": float,
            "mean_hd95_wt": float, ...
            "num_patients": int,
            "num_et_absent": int,  # ET 없는 환자 수
        }
    """
    regions = ["wt", "tc", "et"]
    summary = {"num_patients": len(all_patient_metrics)}

    # ET 없는 환자 수 카운트
    et_absent_count = sum(
        1 for m in all_patient_metrics if not m.get("et_present_in_gt", True)
    )
    summary["num_et_absent"] = et_absent_count

    for region in regions:
        dice_key = f"dice_{region}"
        hd95_key = f"hd95_{region}"

        if region == "et" and exclude_et_absent:
            # ET는 GT에 ET가 있는 환자만 포함
            filtered = [m for m in all_patient_metrics
                        if m.get("et_present_in_gt", True)]
            if len(filtered) == 0:
                summary[f"mean_{dice_key}"] = float("nan")
                summary[f"std_{dice_key}"] = float("nan")
                summary[f"mean_{hd95_key}"] = float("nan")
                summary[f"std_{hd95_key}"] = float("nan")
                continue
        else:
            filtered = all_patient_metrics

        dice_vals = [m[dice_key] for m in filtered]
        hd95_vals = [m[hd95_key] for m in filtered]

        summary[f"mean_{dice_key}"] = float(np.mean(dice_vals))
        summary[f"std_{dice_key}"] = float(np.std(dice_vals))
        summary[f"mean_{hd95_key}"] = float(np.mean(hd95_vals))
        summary[f"std_{hd95_key}"] = float(np.std(hd95_vals))

    return summary


def print_metrics_summary(summary: dict):
    """평가 결과 요약 출력."""
    print("=" * 60)
    print(f"  Volume-Level Evaluation Summary ({summary['num_patients']} patients)")
    print(f"  ET-absent patients: {summary['num_et_absent']}")
    print("=" * 60)
    for region in ["wt", "tc", "et"]:
        d_mean = summary.get(f"mean_dice_{region}", float("nan"))
        d_std = summary.get(f"std_dice_{region}", float("nan"))
        h_mean = summary.get(f"mean_hd95_{region}", float("nan"))
        h_std = summary.get(f"std_hd95_{region}", float("nan"))
        tag = region.upper()
        note = " (ET-present only)" if region == "et" else ""
        print(f"  {tag}{note}:")
        print(f"    Dice = {d_mean:.4f} ± {d_std:.4f}")
        print(f"    HD95 = {h_mean:.2f} ± {h_std:.2f} mm")
    print("=" * 60)
